import express from 'express';
import { db } from '../index.js';
import { campaignGroups } from '../shared/schema.js';
import { eq, and } from 'drizzle-orm';
import { authenticateToken } from '../middleware/auth.js';

export const campaignGroupsRouter = express.Router();

// Get all campaign groups for authenticated user
campaignGroupsRouter.get('/', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const userCampaignGroups = await db.select().from(campaignGroups).where(eq(campaignGroups.userId, userId));
    res.json(userCampaignGroups);
  } catch (error) {
    console.error('Get campaign groups error:', error);
    res.status(500).json({ error: 'Failed to fetch campaign groups' });
  }
});

// Create new campaign group
campaignGroupsRouter.post('/', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const { name, description } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: 'Name is required' });
    }

    const [newCampaignGroup] = await db.insert(campaignGroups).values({
      userId,
      name,
      description
    }).returning();

    res.status(201).json(newCampaignGroup);
  } catch (error) {
    console.error('Create campaign group error:', error);
    res.status(500).json({ error: 'Failed to create campaign group' });
  }
});

// Update campaign group
campaignGroupsRouter.put('/:id', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const campaignGroupId = parseInt(req.params.id);
    const { name, description } = req.body;

    const [updatedCampaignGroup] = await db.update(campaignGroups)
      .set({ name, description, updatedAt: new Date() })
      .where(and(eq(campaignGroups.id, campaignGroupId), eq(campaignGroups.userId, userId)))
      .returning();

    if (!updatedCampaignGroup) {
      return res.status(404).json({ error: 'Campaign group not found' });
    }

    res.json(updatedCampaignGroup);
  } catch (error) {
    console.error('Update campaign group error:', error);
    res.status(500).json({ error: 'Failed to update campaign group' });
  }
});

// Delete campaign group
campaignGroupsRouter.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const campaignGroupId = parseInt(req.params.id);

    const [deletedCampaignGroup] = await db.delete(campaignGroups)
      .where(and(eq(campaignGroups.id, campaignGroupId), eq(campaignGroups.userId, userId)))
      .returning();

    if (!deletedCampaignGroup) {
      return res.status(404).json({ error: 'Campaign group not found' });
    }

    res.json({ message: 'Campaign group deleted successfully' });
  } catch (error) {
    console.error('Delete campaign group error:', error);
    res.status(500).json({ error: 'Failed to delete campaign group' });
  }
});