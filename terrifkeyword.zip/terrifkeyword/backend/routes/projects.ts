import express from 'express';
import { db } from '../index.js';
import { projects } from '../shared/schema.js';
import { eq, and } from 'drizzle-orm';
import { authenticateToken } from '../middleware/auth.js';

export const projectsRouter = express.Router();

// Get all projects for authenticated user
projectsRouter.get('/', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const userProjects = await db.select().from(projects).where(eq(projects.userId, userId));
    res.json(userProjects);
  } catch (error) {
    console.error('Get projects error:', error);
    res.status(500).json({ error: 'Failed to fetch projects' });
  }
});

// Create new project
projectsRouter.post('/', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const { name, topic, country, countryLocationId, language, languageCode, aiCreationPrompt } = req.body;
    
    if (!name || !country || !language) {
      return res.status(400).json({ error: 'Name, country, and language are required' });
    }

    const [newProject] = await db.insert(projects).values({
      userId,
      name,
      topic,
      country,
      countryLocationId,
      language,
      languageCode,
      aiCreationPrompt
    }).returning();

    res.status(201).json(newProject);
  } catch (error) {
    console.error('Create project error:', error);
    res.status(500).json({ error: 'Failed to create project' });
  }
});

// Update project
projectsRouter.put('/:id', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const projectId = parseInt(req.params.id);
    const { name, topic, country, countryLocationId, language, languageCode, aiCreationPrompt } = req.body;

    const [updatedProject] = await db.update(projects)
      .set({
        name,
        topic,
        country,
        countryLocationId,
        language,
        languageCode,
        aiCreationPrompt,
        updatedAt: new Date()
      })
      .where(and(eq(projects.id, projectId), eq(projects.userId, userId)))
      .returning();

    if (!updatedProject) {
      return res.status(404).json({ error: 'Project not found' });
    }

    res.json(updatedProject);
  } catch (error) {
    console.error('Update project error:', error);
    res.status(500).json({ error: 'Failed to update project' });
  }
});

// Delete project
projectsRouter.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const projectId = parseInt(req.params.id);

    const [deletedProject] = await db.delete(projects)
      .where(and(eq(projects.id, projectId), eq(projects.userId, userId)))
      .returning();

    if (!deletedProject) {
      return res.status(404).json({ error: 'Project not found' });
    }

    res.json({ message: 'Project deleted successfully' });
  } catch (error) {
    console.error('Delete project error:', error);
    res.status(500).json({ error: 'Failed to delete project' });
  }
});