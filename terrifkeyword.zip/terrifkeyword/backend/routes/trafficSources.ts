import express from 'express';
import { db } from '../index.js';
import { trafficSources } from '../shared/schema.js';
import { eq, and } from 'drizzle-orm';
import { authenticateToken } from '../middleware/auth.js';

export const trafficSourcesRouter = express.Router();

// Get all traffic sources for authenticated user
trafficSourcesRouter.get('/', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const userTrafficSources = await db.select().from(trafficSources).where(eq(trafficSources.userId, userId));
    res.json(userTrafficSources);
  } catch (error) {
    console.error('Get traffic sources error:', error);
    res.status(500).json({ error: 'Failed to fetch traffic sources' });
  }
});

// Create new traffic source
trafficSourcesRouter.post('/', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const { name, description } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: 'Name is required' });
    }

    const [newTrafficSource] = await db.insert(trafficSources).values({
      userId,
      name,
      description
    }).returning();

    res.status(201).json(newTrafficSource);
  } catch (error) {
    console.error('Create traffic source error:', error);
    res.status(500).json({ error: 'Failed to create traffic source' });
  }
});

// Update traffic source
trafficSourcesRouter.put('/:id', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const trafficSourceId = parseInt(req.params.id);
    const { name, description } = req.body;

    const [updatedTrafficSource] = await db.update(trafficSources)
      .set({ name, description, updatedAt: new Date() })
      .where(and(eq(trafficSources.id, trafficSourceId), eq(trafficSources.userId, userId)))
      .returning();

    if (!updatedTrafficSource) {
      return res.status(404).json({ error: 'Traffic source not found' });
    }

    res.json(updatedTrafficSource);
  } catch (error) {
    console.error('Update traffic source error:', error);
    res.status(500).json({ error: 'Failed to update traffic source' });
  }
});

// Delete traffic source
trafficSourcesRouter.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const trafficSourceId = parseInt(req.params.id);

    const [deletedTrafficSource] = await db.delete(trafficSources)
      .where(and(eq(trafficSources.id, trafficSourceId), eq(trafficSources.userId, userId)))
      .returning();

    if (!deletedTrafficSource) {
      return res.status(404).json({ error: 'Traffic source not found' });
    }

    res.json({ message: 'Traffic source deleted successfully' });
  } catch (error) {
    console.error('Delete traffic source error:', error);
    res.status(500).json({ error: 'Failed to delete traffic source' });
  }
});