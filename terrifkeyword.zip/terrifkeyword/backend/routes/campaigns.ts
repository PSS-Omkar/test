import express from 'express';
import { db } from '../index.js';
import { campaigns, projects } from '../shared/schema.js';
import { eq, and } from 'drizzle-orm';
import { authenticateToken } from '../middleware/auth.js';

export const campaignsRouter = express.Router();

// Get all campaigns for authenticated user
campaignsRouter.get('/', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    
    const userCampaigns = await db
      .select({
        campaign: campaigns,
        project: projects
      })
      .from(campaigns)
      .leftJoin(projects, eq(campaigns.projectId, projects.id))
      .where(eq(projects.userId, userId));

    res.json(userCampaigns.map(row => ({
      ...row.campaign,
      project: row.project
    })));
  } catch (error) {
    console.error('Get campaigns error:', error);
    res.status(500).json({ error: 'Failed to fetch campaigns' });
  }
});

// Create new campaign
campaignsRouter.post('/', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const { projectId, advertiserId, trafficSourceId, name, primaryText, headline, description, cta, image, video } = req.body;
    
    // Verify project belongs to user
    const [project] = await db.select().from(projects).where(and(eq(projects.id, projectId), eq(projects.userId, userId))).limit(1);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const [newCampaign] = await db.insert(campaigns).values({
      projectId,
      advertiserId,
      trafficSourceId,
      name,
      primaryText,
      headline,
      description,
      cta,
      image,
      video
    }).returning();

    res.status(201).json(newCampaign);
  } catch (error) {
    console.error('Create campaign error:', error);
    res.status(500).json({ error: 'Failed to create campaign' });
  }
});

// Update campaign
campaignsRouter.put('/:id', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const campaignId = parseInt(req.params.id);
    const updateData = req.body;

    // Verify campaign belongs to user through project
    const [existingCampaign] = await db
      .select({ campaign: campaigns, project: projects })
      .from(campaigns)
      .leftJoin(projects, eq(campaigns.projectId, projects.id))
      .where(and(eq(campaigns.id, campaignId), eq(projects.userId, userId)))
      .limit(1);

    if (!existingCampaign) {
      return res.status(404).json({ error: 'Campaign not found' });
    }

    const [updatedCampaign] = await db.update(campaigns)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(campaigns.id, campaignId))
      .returning();

    res.json(updatedCampaign);
  } catch (error) {
    console.error('Update campaign error:', error);
    res.status(500).json({ error: 'Failed to update campaign' });
  }
});

// Delete campaign
campaignsRouter.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const campaignId = parseInt(req.params.id);

    // Verify campaign belongs to user through project
    const [existingCampaign] = await db
      .select({ campaign: campaigns, project: projects })
      .from(campaigns)
      .leftJoin(projects, eq(campaigns.projectId, projects.id))
      .where(and(eq(campaigns.id, campaignId), eq(projects.userId, userId)))
      .limit(1);

    if (!existingCampaign) {
      return res.status(404).json({ error: 'Campaign not found' });
    }

    await db.delete(campaigns).where(eq(campaigns.id, campaignId));
    res.json({ message: 'Campaign deleted successfully' });
  } catch (error) {
    console.error('Delete campaign error:', error);
    res.status(500).json({ error: 'Failed to delete campaign' });
  }
});