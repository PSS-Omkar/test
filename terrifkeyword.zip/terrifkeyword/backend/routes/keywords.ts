import express from 'express';
import { db } from '../index.js';
import { keywords, projects } from '../shared/schema.js';
import { eq, and } from 'drizzle-orm';
import { authenticateToken } from '../middleware/auth.js';

export const keywordsRouter = express.Router();

// Get all keywords for authenticated user
keywordsRouter.get('/', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    
    const userKeywords = await db
      .select({
        keyword: keywords,
        project: projects
      })
      .from(keywords)
      .leftJoin(projects, eq(keywords.projectId, projects.id))
      .where(eq(projects.userId, userId));

    res.json(userKeywords.map(row => ({
      ...row.keyword,
      project: row.project
    })));
  } catch (error) {
    console.error('Get keywords error:', error);
    res.status(500).json({ error: 'Failed to fetch keywords' });
  }
});

// Create new keyword
keywordsRouter.post('/', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const { projectId, keyword, volume, bid } = req.body;
    
    // Verify project belongs to user
    const [project] = await db.select().from(projects).where(and(eq(projects.id, projectId), eq(projects.userId, userId))).limit(1);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const [newKeyword] = await db.insert(keywords).values({
      projectId,
      keyword,
      volume,
      bid
    }).returning();

    res.status(201).json(newKeyword);
  } catch (error) {
    console.error('Create keyword error:', error);
    res.status(500).json({ error: 'Failed to create keyword' });
  }
});

// Bulk create keywords
keywordsRouter.post('/bulk', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const { projectId, keywords: keywordList } = req.body;
    
    // Verify project belongs to user
    const [project] = await db.select().from(projects).where(and(eq(projects.id, projectId), eq(projects.userId, userId))).limit(1);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const keywordsToInsert = keywordList.map((kw: any) => ({
      projectId,
      keyword: kw.keyword,
      volume: kw.volume || null,
      bid: kw.bid || null
    }));

    const newKeywords = await db.insert(keywords).values(keywordsToInsert).returning();
    res.status(201).json(newKeywords);
  } catch (error) {
    console.error('Bulk create keywords error:', error);
    res.status(500).json({ error: 'Failed to create keywords' });
  }
});

// Update keyword
keywordsRouter.put('/:id', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const keywordId = parseInt(req.params.id);
    const { keyword, volume, bid } = req.body;

    // Verify keyword belongs to user through project
    const [existingKeyword] = await db
      .select({ keyword: keywords, project: projects })
      .from(keywords)
      .leftJoin(projects, eq(keywords.projectId, projects.id))
      .where(and(eq(keywords.id, keywordId), eq(projects.userId, userId)))
      .limit(1);

    if (!existingKeyword) {
      return res.status(404).json({ error: 'Keyword not found' });
    }

    const [updatedKeyword] = await db.update(keywords)
      .set({ keyword, volume, bid, updatedAt: new Date() })
      .where(eq(keywords.id, keywordId))
      .returning();

    res.json(updatedKeyword);
  } catch (error) {
    console.error('Update keyword error:', error);
    res.status(500).json({ error: 'Failed to update keyword' });
  }
});

// Delete keyword
keywordsRouter.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const keywordId = parseInt(req.params.id);

    // Verify keyword belongs to user through project
    const [existingKeyword] = await db
      .select({ keyword: keywords, project: projects })
      .from(keywords)
      .leftJoin(projects, eq(keywords.projectId, projects.id))
      .where(and(eq(keywords.id, keywordId), eq(projects.userId, userId)))
      .limit(1);

    if (!existingKeyword) {
      return res.status(404).json({ error: 'Keyword not found' });
    }

    await db.delete(keywords).where(eq(keywords.id, keywordId));
    res.json({ message: 'Keyword deleted successfully' });
  } catch (error) {
    console.error('Delete keyword error:', error);
    res.status(500).json({ error: 'Failed to delete keyword' });
  }
});