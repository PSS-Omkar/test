import express from 'express';
import { db } from '../index.js';
import { advertisers } from '../shared/schema.js';
import { eq, and } from 'drizzle-orm';
import { authenticateToken } from '../middleware/auth.js';

export const advertisersRouter = express.Router();

// Get all advertisers for authenticated user
advertisersRouter.get('/', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const userAdvertisers = await db.select().from(advertisers).where(eq(advertisers.userId, userId));
    res.json(userAdvertisers);
  } catch (error) {
    console.error('Get advertisers error:', error);
    res.status(500).json({ error: 'Failed to fetch advertisers' });
  }
});

// Create new advertiser
advertisersRouter.post('/', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const { name, description } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: 'Name is required' });
    }

    const [newAdvertiser] = await db.insert(advertisers).values({
      userId,
      name,
      description
    }).returning();

    res.status(201).json(newAdvertiser);
  } catch (error) {
    console.error('Create advertiser error:', error);
    res.status(500).json({ error: 'Failed to create advertiser' });
  }
});

// Update advertiser
advertisersRouter.put('/:id', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const advertiserId = parseInt(req.params.id);
    const { name, description } = req.body;

    const [updatedAdvertiser] = await db.update(advertisers)
      .set({ name, description, updatedAt: new Date() })
      .where(and(eq(advertisers.id, advertiserId), eq(advertisers.userId, userId)))
      .returning();

    if (!updatedAdvertiser) {
      return res.status(404).json({ error: 'Advertiser not found' });
    }

    res.json(updatedAdvertiser);
  } catch (error) {
    console.error('Update advertiser error:', error);
    res.status(500).json({ error: 'Failed to update advertiser' });
  }
});

// Delete advertiser
advertisersRouter.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const userId = (req as any).user.userId;
    const advertiserId = parseInt(req.params.id);

    const [deletedAdvertiser] = await db.delete(advertisers)
      .where(and(eq(advertisers.id, advertiserId), eq(advertisers.userId, userId)))
      .returning();

    if (!deletedAdvertiser) {
      return res.status(404).json({ error: 'Advertiser not found' });
    }

    res.json({ message: 'Advertiser deleted successfully' });
  } catch (error) {
    console.error('Delete advertiser error:', error);
    res.status(500).json({ error: 'Failed to delete advertiser' });
  }
});