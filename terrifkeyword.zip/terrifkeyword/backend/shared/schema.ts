import { pgTable, text, varchar, timestamp, jsonb, index, serial, boolean, integer, decimal, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)]
);

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Projects table
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name").notNull(),
  topic: varchar("topic"),
  country: varchar("country").notNull(),
  countryLocationId: varchar("country_location_id"),
  language: varchar("language").notNull(),
  languageCode: varchar("language_code"),
  aiCreationPrompt: text("ai_creation_prompt"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Advertisers table
export const advertisers = pgTable("advertisers", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Traffic Sources table
export const trafficSources = pgTable("traffic_sources", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Keywords table
export const keywords = pgTable("keywords", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id")
    .notNull()
    .references(() => projects.id, { onDelete: "cascade" }),
  keyword: varchar("keyword").notNull(),
  volume: integer("volume"),
  bid: decimal("bid", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Campaigns table
export const campaigns = pgTable("campaigns", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id")
    .notNull()
    .references(() => projects.id, { onDelete: "cascade" }),
  advertiserId: integer("advertiser_id")
    .notNull()
    .references(() => advertisers.id, { onDelete: "cascade" }),
  trafficSourceId: integer("traffic_source_id").references(() => trafficSources.id),
  name: varchar("name").notNull(),
  primaryText: text("primary_text"),
  headline: varchar("headline"),
  description: text("description"),
  cta: varchar("cta"),
  image: varchar("image"),
  video: varchar("video"),
  status: varchar("status").default("active"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Campaign Groups table
export const campaignGroups = pgTable("campaign_groups", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Meta Campaigns table
export const metaCampaigns = pgTable("meta_campaigns", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id")
    .notNull()
    .references(() => campaigns.id, { onDelete: "cascade" }),
  metaCampaignId: varchar("meta_campaign_id"),
  adSetId: varchar("ad_set_id"),
  adId: varchar("ad_id"),
  status: varchar("status").default("active"),
  budget: decimal("budget", { precision: 10, scale: 2 }),
  targetingData: jsonb("targeting_data"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  projects: many(projects),
  advertisers: many(advertisers),
  trafficSources: many(trafficSources),
  campaignGroups: many(campaignGroups),
}));

export const projectsRelations = relations(projects, ({ one, many }) => ({
  user: one(users, {
    fields: [projects.userId],
    references: [users.id],
  }),
  keywords: many(keywords),
  campaigns: many(campaigns),
}));

export const advertisersRelations = relations(advertisers, ({ one, many }) => ({
  user: one(users, {
    fields: [advertisers.userId],
    references: [users.id],
  }),
  campaigns: many(campaigns),
}));

export const trafficSourcesRelations = relations(trafficSources, ({ one, many }) => ({
  user: one(users, {
    fields: [trafficSources.userId],
    references: [users.id],
  }),
  campaigns: many(campaigns),
}));

export const keywordsRelations = relations(keywords, ({ one }) => ({
  project: one(projects, {
    fields: [keywords.projectId],
    references: [projects.id],
  }),
}));

export const campaignsRelations = relations(campaigns, ({ one, many }) => ({
  project: one(projects, {
    fields: [campaigns.projectId],
    references: [projects.id],
  }),
  advertiser: one(advertisers, {
    fields: [campaigns.advertiserId],
    references: [advertisers.id],
  }),
  trafficSource: one(trafficSources, {
    fields: [campaigns.trafficSourceId],
    references: [trafficSources.id],
  }),
  metaCampaigns: many(metaCampaigns),
}));

export const campaignGroupsRelations = relations(campaignGroups, ({ one }) => ({
  user: one(users, {
    fields: [campaignGroups.userId],
    references: [users.id],
  }),
}));

// Insert schemas for validation
export const insertUserSchema = createInsertSchema(users);
export const insertProjectSchema = createInsertSchema(projects);
export const insertAdvertiserSchema = createInsertSchema(advertisers);
export const insertTrafficSourceSchema = createInsertSchema(trafficSources);
export const insertKeywordSchema = createInsertSchema(keywords);
export const insertCampaignSchema = createInsertSchema(campaigns);
export const insertCampaignGroupSchema = createInsertSchema(campaignGroups);