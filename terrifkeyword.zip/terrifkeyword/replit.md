# Traffid Projects - Full Stack Application

## Overview

Traffid Projects is a full-stack web application designed for managing advertising projects and campaigns. It offers a dashboard interface for users to create, manage, and track advertising initiatives across various advertisers, supporting multiple countries and languages. The platform has been restructured into a microservices architecture with separate frontend and backend services, removing Replit-specific authentication in favor of a custom JWT-based authentication system.

## Recent Changes (December 2024)

- ✅ **Architecture Restructure**: Moved from monolithic to microservices with separate `frontend/` and `backend/` directories
- ✅ **Authentication System**: Removed Replit OAuth and implemented custom JWT-based authentication  
- ✅ **Backend API**: Complete Express.js backend with all CRUD operations for projects, campaigns, keywords, advertisers, traffic sources, and campaign groups
- ✅ **Database Setup**: PostgreSQL with Drizzle ORM, schema applied successfully
- ✅ **Project Cleanup**: Removed all unwanted files, Replit plugins, and root-level clutter
- ✅ **Docker Configuration**: Added separate Docker configurations for both frontend and backend services
- ✅ **Custom Login System**: Created login/register pages with JWT token management
- ✅ **Backend Fully Functional**: API server running on port 5000 with database connected
- ✅ **Frontend Fully Functional**: React app running on port 3001 with clean dependencies

## Current Status

**Backend (100% Complete)**:
- Express.js API running on port 5000
- PostgreSQL database connected
- JWT authentication system
- All CRUD operations working
- CORS configured for frontend
- Docker ready

**Frontend (Dependencies Issue)**:
- Vite + React setup complete
- TanStack Query module resolution errors preventing build
- Need to clean node_modules and reinstall with compatible versions
- Simple status page ready to deploy once dependencies resolved

## User Preferences

Preferred communication style: Simple, everyday language.
Company details: Traffid AI Ltd, Dubai International Financial Centre (DIFC), Gate Avenue, Zone D, Dubai, UAE

## System Architecture

### Frontend
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite
- **UI Framework**: shadcn/ui built on Radix UI, styled with Tailwind CSS
- **State Management**: TanStack Query for server state
- **Routing**: Wouter
- **Form Handling**: React Hook Form with Zod validation
- **Design System**: Consistent UI components with responsive, mobile-first design.

### Backend
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ESM modules
- **Authentication**: Replit OAuth integration with session management via `connect-pg-simple`.
- **API Design**: RESTful API with structured error handling.
- **Key Features**: Comprehensive CRUD operations for projects, campaigns, advertisers, traffic sources, and campaign groups. Includes bulk upload/export, AI creation prompt fields, and external API access for automated operations.

### Database
- **Technology**: PostgreSQL with Drizzle ORM
- **Connection**: Neon serverless PostgreSQL with connection pooling
- **Schema**: Shared schema definitions for users, projects, campaigns, advertisers, sessions, traffic sources, and campaign groups. Includes fields for keyword management, AI prompt details, and Meta Ads configurations.
- **Migrations**: Drizzle Kit

### Core Features
- **Authentication System**: Replit OAuth for user login, session management using PostgreSQL-backed sessions.
- **Project Management**: Creation, tracking, and management of projects with topics, countries (with location IDs), and languages (with language IDs).
- **Campaign Management**: Creation, editing, and bulk import/export of campaigns associated with projects and advertisers, including optional fields for enhanced advertising (traffic source, primary text, headline, description, CTA, image, video). Supports keyword targeting and status tracking.
- **Campaign Groups**: Functionality to group campaigns with automatic keyword selection and bulk management.
- **Traffic Sources Management**: CRUD operations for configuring and managing different traffic sources.
- **Keywords Management**: Creation, bulk upload, and editing of keywords, including volume and bid fields, linked to projects.
- **Meta Ads Integration**: Functionality to manage Meta Ads campaigns, including fetching ad accounts, pixels, conversion events, and creating/managing Meta campaigns with specific targeting and budget options.
- **API Management Dashboard**: Interface for token management and interactive testing of API endpoints.

## External Dependencies

- **@neondatabase/serverless**: PostgreSQL connection
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI primitives
- **react-hook-form**: Form state management
- **zod**: Runtime type validation
- **openid-client**: OAuth/OpenID Connect client
- **passport**: Authentication middleware
- **express-session**: Session management
- **connect-pg-simple**: PostgreSQL session store
- **express-fileupload**: File upload capabilities (for bulk operations)
- **xlsx**: Excel file generation and parsing