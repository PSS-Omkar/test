import { NavigationHeader } from "@/components/NavigationHeader";
import { ProjectsTable } from "@/components/ProjectsTable";

export default function Projects() {

  return (
    <div className="min-h-screen bg-slate-50">
      <NavigationHeader />
      
      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Projects</h1>
              <p className="mt-1 text-sm text-slate-600">Manage your advertising projects</p>
            </div>
          </div>
        </div>

        {/* Projects Table */}
        <ProjectsTable />
      </div>
    </div>
  );
}
