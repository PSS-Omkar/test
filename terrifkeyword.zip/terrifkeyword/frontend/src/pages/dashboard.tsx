import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { NavigationHeader } from "@/components/NavigationHeader";
import { StatsCards } from "@/components/StatsCards";
import { ProjectsTable } from "@/components/ProjectsTable";
import { apiRequest } from "@/lib/queryClient";

export default function Dashboard() {
  const { toast } = useToast();

  return (
    <div className="min-h-screen bg-slate-50">
      <NavigationHeader />
      
      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
        {/* Dashboard Header */}
        <div className="mb-6 sm:mb-8">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900">Project Dashboard</h1>
              <p className="mt-1 text-sm text-slate-600">Manage your advertising projects and campaigns</p>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <StatsCards />

        {/* Projects Table */}
        <ProjectsTable />
      </div>
    </div>
  );
}
