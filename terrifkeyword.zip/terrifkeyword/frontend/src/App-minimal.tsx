function App() {
  const testBackend = async () => {
    try {
      const response = await fetch('/api/auth/status');
      const data = await response.json();
      alert(`Backend Status: ${data.message}`);
    } catch (error) {
      alert('Backend connection failed');
    }
  };

  return (
    <div style={{ fontFamily: 'system-ui', padding: '2rem', maxWidth: '800px', margin: '0 auto' }}>
      <h1 style={{ color: '#333', marginBottom: '1rem' }}>
        Traffid Projects - Backend Ready!
      </h1>
      
      <div style={{ background: '#f8f9fa', padding: '1.5rem', borderRadius: '8px', marginBottom: '2rem' }}>
        <h2 style={{ color: '#28a745', marginBottom: '1rem' }}>✅ System Status</h2>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          <li style={{ marginBottom: '0.5rem' }}>🚀 Express.js backend running on port 5000</li>
          <li style={{ marginBottom: '0.5rem' }}>🗄️ PostgreSQL database connected</li>
          <li style={{ marginBottom: '0.5rem' }}>🔐 JWT authentication system ready</li>
          <li style={{ marginBottom: '0.5rem' }}>📁 Microservices architecture implemented</li>
        </ul>
      </div>

      <div style={{ background: '#e3f2fd', padding: '1.5rem', borderRadius: '8px', marginBottom: '2rem' }}>
        <h3 style={{ color: '#1565c0', marginBottom: '1rem' }}>Available API Endpoints</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1rem' }}>
          <div style={{ background: 'white', padding: '1rem', borderRadius: '4px' }}>
            <strong>Authentication</strong>
            <br />POST /api/auth/register
            <br />POST /api/auth/login
            <br />GET /api/auth/me
          </div>
          <div style={{ background: 'white', padding: '1rem', borderRadius: '4px' }}>
            <strong>Projects</strong>
            <br />GET/POST/PUT/DELETE
            <br />/api/projects
          </div>
          <div style={{ background: 'white', padding: '1rem', borderRadius: '4px' }}>
            <strong>Campaigns</strong>
            <br />GET/POST/PUT/DELETE
            <br />/api/campaigns
          </div>
          <div style={{ background: 'white', padding: '1rem', borderRadius: '4px' }}>
            <strong>Keywords</strong>
            <br />GET/POST/PUT/DELETE
            <br />/api/keywords
          </div>
          <div style={{ background: 'white', padding: '1rem', borderRadius: '4px' }}>
            <strong>Advertisers</strong>
            <br />GET/POST/PUT/DELETE
            <br />/api/advertisers
          </div>
          <div style={{ background: 'white', padding: '1rem', borderRadius: '4px' }}>
            <strong>Traffic Sources</strong>
            <br />GET/POST/PUT/DELETE
            <br />/api/traffic-sources
          </div>
        </div>
      </div>

      <div style={{ textAlign: 'center' }}>
        <button 
          onClick={testBackend}
          style={{
            background: '#007bff',
            color: 'white',
            border: 'none',
            padding: '12px 24px',
            borderRadius: '6px',
            fontSize: '16px',
            cursor: 'pointer',
            marginRight: '1rem'
          }}
        >
          Test Backend Connection
        </button>
        <p style={{ color: '#666', marginTop: '1rem' }}>
          Backend is running successfully. Frontend dependencies are being resolved.
        </p>
      </div>
    </div>
  );
}

export default App;