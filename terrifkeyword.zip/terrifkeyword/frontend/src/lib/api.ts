import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Create axios instance
export const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add auth interceptor
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('auth_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Add response interceptor to handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401 || error.response?.status === 403) {
      localStorage.removeItem('auth_token');
      localStorage.removeItem('user_data');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API calls
export const authApi = {
  login: (email: string, password: string) => api.post('/auth/login', { email, password }),
  register: (email: string, password: string, firstName?: string, lastName?: string) => 
    api.post('/auth/register', { email, password, firstName, lastName }),
  getCurrentUser: () => api.get('/auth/me'),
};

// Project API calls
export const projectsApi = {
  getAll: () => api.get('/projects'),
  create: (data: any) => api.post('/projects', data),
  update: (id: number, data: any) => api.put(`/projects/${id}`, data),
  delete: (id: number) => api.delete(`/projects/${id}`),
};

// Campaign API calls
export const campaignsApi = {
  getAll: () => api.get('/campaigns'),
  create: (data: any) => api.post('/campaigns', data),
  update: (id: number, data: any) => api.put(`/campaigns/${id}`, data),
  delete: (id: number) => api.delete(`/campaigns/${id}`),
};

// Keyword API calls
export const keywordsApi = {
  getAll: () => api.get('/keywords'),
  create: (data: any) => api.post('/keywords', data),
  createBulk: (data: any) => api.post('/keywords/bulk', data),
  update: (id: number, data: any) => api.put(`/keywords/${id}`, data),
  delete: (id: number) => api.delete(`/keywords/${id}`),
};

// Advertiser API calls
export const advertisersApi = {
  getAll: () => api.get('/advertisers'),
  create: (data: any) => api.post('/advertisers', data),
  update: (id: number, data: any) => api.put(`/advertisers/${id}`, data),
  delete: (id: number) => api.delete(`/advertisers/${id}`),
};

// Traffic Source API calls
export const trafficSourcesApi = {
  getAll: () => api.get('/traffic-sources'),
  create: (data: any) => api.post('/traffic-sources', data),
  update: (id: number, data: any) => api.put(`/traffic-sources/${id}`, data),
  delete: (id: number) => api.delete(`/traffic-sources/${id}`),
};

// Campaign Group API calls
export const campaignGroupsApi = {
  getAll: () => api.get('/campaign-groups'),
  create: (data: any) => api.post('/campaign-groups', data),
  update: (id: number, data: any) => api.put(`/campaign-groups/${id}`, data),
  delete: (id: number) => api.delete(`/campaign-groups/${id}`),
};