import React, { useState, useEffect } from 'react';

function App() {
  const [backendStatus, setBackendStatus] = useState<string>('Checking...');

  useEffect(() => {
    // Test backend connection
    fetch('/api/auth/status')
      .then(() => setBackendStatus('Connected ✅'))
      .catch(() => setBackendStatus('Connection failed ❌'));
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <header className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900">Traffid Projects</h1>
          <p className="text-lg text-gray-600 mt-2">
            Full-stack advertising project management platform
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Backend Status</h2>
            <div className="space-y-2">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                <span className="text-sm text-gray-600">Express.js API running on port 5000</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                <span className="text-sm text-gray-600">PostgreSQL database connected</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                <span className="text-sm text-gray-600">JWT authentication system</span>
              </div>
              <div className="mt-4 p-3 bg-gray-50 rounded">
                <span className="text-sm font-medium">Connection Test: {backendStatus}</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Available Features</h2>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>✅ User authentication (login/register)</li>
              <li>✅ Project management</li>
              <li>✅ Campaign management</li>
              <li>✅ Keyword management</li>
              <li>✅ Advertiser management</li>
              <li>✅ Traffic source management</li>
            </ul>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Architecture</h2>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><strong>Frontend:</strong> React + TypeScript + Vite</li>
              <li><strong>Backend:</strong> Express.js + TypeScript</li>
              <li><strong>Database:</strong> PostgreSQL + Drizzle ORM</li>
              <li><strong>Deployment:</strong> Docker support</li>
            </ul>
          </div>
        </div>

        <div className="mt-8 bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Quick Test</h2>
          <p className="text-gray-600 mb-4">
            The backend API is running and ready to accept requests. All CRUD operations are available for:
          </p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 p-4 rounded">
              <h3 className="font-medium text-blue-800">Authentication</h3>
              <p className="text-sm text-blue-600">POST /api/auth/login<br/>POST /api/auth/register</p>
            </div>
            <div className="bg-green-50 p-4 rounded">
              <h3 className="font-medium text-green-800">Projects</h3>
              <p className="text-sm text-green-600">GET/POST/PUT/DELETE /api/projects</p>
            </div>
            <div className="bg-purple-50 p-4 rounded">
              <h3 className="font-medium text-purple-800">Campaigns</h3>
              <p className="text-sm text-purple-600">GET/POST/PUT/DELETE /api/campaigns</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;