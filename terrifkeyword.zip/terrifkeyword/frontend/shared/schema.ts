// Copy the schema from backend/shared/schema.ts
export * from '../../backend/shared/schema.js';