import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "./components/ui/toaster";
import { TooltipProvider } from "./components/ui/tooltip";
import Landing from "./pages/landing";
import Dashboard from "./pages/dashboard";
import Projects from "./pages/projects";
import Campaigns from "./pages/campaigns";
import Advertisers from "./pages/advertisers";
import Keywords from "./pages/keywords";
import TrafficSources from "./pages/traffic-sources";
import ApiPage from "./pages/api";
import MetaAds from "./pages/meta-ads";
import Privacy from "./pages/privacy";
import NotFound from "./pages/not-found";

// Protected Route Component
// function ({ children }: { children: React.ReactNode }) {
//   const { isAuthenticated, isLoading } = useAuth();

//   if (isLoading) {
//     return (
//       <div className="min-h-screen w-full flex items-center justify-center bg-gray-50">
//         <div className="text-center">
//           <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
//           <p className="mt-2 text-sm text-gray-600">Loading...</p>
//         </div>
//       </div>
//     );
//   }

//   if (!isAuthenticated) {
//     return <Navigate to="/" replace />;
//   }

//   return <>{children}</>;
// }

function AppRoutes() {
  return (
    <Routes>
      {/* Root route - redirect to dashboard */}
      <Route path="/" element={<Navigate to="/dashboard" replace />} />

      {/* Public routes */}
      <Route path="/privacy" element={<Privacy />} />

      {/* Protected routes */}
      <Route
        path="/dashboard"
        element={
          // <>
          <Dashboard />
          // </>
        }
      />
      <Route
        path="/projects"
        element={
          <>
            <Projects />
          </>
        }
      />
      <Route
        path="/campaigns"
        element={
          <>
            <Campaigns />
          </>
        }
      />
      <Route
        path="/advertisers"
        element={
          <>
            <Advertisers />
          </>
        }
      />
      <Route
        path="/keywords"
        element={
          <>
            <Keywords />
          </>
        }
      />
      <Route
        path="/traffic-sources"
        element={
          <>
            <TrafficSources />
          </>
        }
      />
      <Route
        path="/meta-ads"
        element={
          <>
            <MetaAds />
          </>
        }
      />
      <Route
        path="/api"
        element={
          // <>
          <ApiPage />
          // </>
        }
      />

      {/* 404 route */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <TooltipProvider>
          <Toaster />
          <AppRoutes />
        </TooltipProvider>
      </BrowserRouter>
    </QueryClientProvider>
  );
}

export default App;
